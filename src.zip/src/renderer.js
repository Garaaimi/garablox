'use strict';

/* =========================================================================
   GaraBlox — интерфейс
   В Electron используется мост window.garablox (preload.js).
   Если файл открыт просто в браузере, включается демо-режим с заглушками.
   ========================================================================= */

const api = window.garablox ?? createDemoApi();

/* ------------------------------- данные -------------------------------- */

const THEMES = [
  { id: 'midnight', name: 'Полночь', sub: 'фиолет + циан', dot: 'linear-gradient(135deg,#8b5cf6,#22d3ee)', bg: '#0a0a11', surface: '#14141f', accent: 'linear-gradient(120deg,#8b5cf6,#22d3ee)' },
  { id: 'aurora', name: 'Аврора', sub: 'изумруд + небо', dot: 'linear-gradient(135deg,#34d399,#38bdf8)', bg: '#05100f', surface: '#0c1f1d', accent: 'linear-gradient(120deg,#34d399,#38bdf8)' },
  { id: 'carbon', name: 'Карбон', sub: 'графит + янтарь', dot: 'linear-gradient(135deg,#f97316,#facc15)', bg: '#0a0a0a', surface: '#161616', accent: 'linear-gradient(120deg,#f97316,#facc15)' },
  { id: 'sakura', name: 'Сакура', sub: 'роза + лаванда', dot: 'linear-gradient(135deg,#f472b6,#a78bfa)', bg: '#140910', surface: '#24111e', accent: 'linear-gradient(120deg,#f472b6,#a78bfa)' },
  { id: 'daylight', name: 'День', sub: 'светлая тема', dot: 'linear-gradient(135deg,#6d28d9,#0ea5e9)', bg: '#eef0f7', surface: '#ffffff', accent: 'linear-gradient(120deg,#6d28d9,#0ea5e9)' }
];

const ACCENTS = [
  { id: 'violet', name: 'Фиолет', a: '#8b5cf6', b: '#22d3ee' },
  { id: 'emerald', name: 'Изумруд', a: '#10b981', b: '#38bdf8' },
  { id: 'sunset', name: 'Закат', a: '#f97316', b: '#f43f5e' },
  { id: 'rose', name: 'Роза', a: '#ec4899', b: '#a78bfa' },
  { id: 'ice', name: 'Лёд', a: '#38bdf8', b: '#818cf8' },
  { id: 'lime', name: 'Лайм', a: '#84cc16', b: '#22d3ee' }
];

const LAUNCH_MODES = [
  { id: 'auto', title: 'Авто', sub: 'системный обработчик roblox:// — обычно официальный клиент' },
  { id: 'roblox', title: 'Оригинальный Roblox', sub: 'всегда открывать через официальный протокол' },
  { id: 'fishstrap', title: 'Fishstrap', sub: 'запуск через Fishstrap.exe' },
  { id: 'bloxstrap', title: 'Bloxstrap', sub: 'запуск через Bloxstrap.exe' },
  { id: 'custom', title: 'Свой .exe', sub: 'любой совместимый бутстраппер' }
];

const NAV = [
  { id: 'home', label: 'Главная', icon: '<path d="M4 10.5 12 4l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5h-5v5H5a1 1 0 0 1-1-1z"/>' },
  { id: 'search', label: 'Поиск', icon: '<circle cx="10.8" cy="10.8" r="6.4"/><path d="M15.6 15.6 20 20"/>' },
  { id: 'friends', label: 'Друзья', icon: '<circle cx="9.4" cy="8.6" r="3.2"/><path d="M3.6 19c.6-3.3 2.9-5 5.8-5s5.2 1.7 5.8 5"/><path d="M16 6.2a3 3 0 0 1 0 5.6M14.6 14.2c2.4.4 3.8 2.1 4.2 4.8"/>' },
  { id: 'accounts', label: 'Аккаунты', icon: '<circle cx="12" cy="8.2" r="3.4"/><path d="M5.4 19.2c.7-3.6 3.3-5.5 6.6-5.5s5.9 1.9 6.6 5.5"/>' },
  { id: 'skins', label: 'Скины', icon: '<circle cx="12" cy="12" r="8.6"/><circle cx="9" cy="9.4" r="1.15"/><circle cx="15" cy="9.4" r="1.15"/><circle cx="8.4" cy="14.2" r="1.15"/><circle cx="15.6" cy="14.2" r="1.15"/>' },
  { id: 'settings', label: 'Настройки', icon: '<path d="M4.5 7.5h15M4.5 12h15M4.5 16.5h15"/><circle cx="9" cy="7.5" r="2.1"/><circle cx="15" cy="12" r="2.1"/><circle cx="8" cy="16.5" r="2.1"/>' }
];

const SORT_LABELS = {
  'top-trending': 'В тренде',
  'up-and-coming': 'Набирают обороты',
  'top-playing-now': 'Сейчас играют',
  'fun-with-friends': 'Для друзей',
  'top-revisited': 'Возвращаются'
};

const ACCOUNT_COLORS = ['#8b5cf6', '#22d3ee', '#34d399', '#f59e0b', '#f43f5e', '#ec4899', '#6366f1', '#14b8a6'];

/* ------------------------------- состояние ----------------------------- */

let state = null;
let clients = { roblox: { installed: false }, fishstrap: { installed: false }, bloxstrap: { installed: false }, protocol: { kind: 'none' } };
let view = 'home';

const ui = {
  installing: false,
  installP: null,
  pendingGame: null,
  pendingConfirm: null,
  editingAccountId: null,
  search: { query: '', games: [], next: null, loading: false, error: null, ran: false },
  recs: { sorts: [], active: 'top-trending', games: [], loading: true, error: null }
};

/* ------------------------------- утилиты ------------------------------- */

const $ = (sel, root = document) => root.querySelector(sel);

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

function cssUrl(url) {
  const safe = String(url).replace(/["'()<>\s]/g, encodeURIComponent);
  return `url("${safe}")`;
}

function artStyle(url, hue) {
  return `style="--hue:${hue}${url ? `;--art:${cssUrl(url)}` : ''}"`;
}

function hueFor(game) {
  const seed = String(game?.placeId || game?.name || '0');
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = (hash * 31 + seed.charCodeAt(i)) % 360;
  return hash;
}

function monogram(name) {
  const clean = String(name || '?').replace(/[^\p{L}\p{N}]/gu, '').trim();
  return (clean[0] || '?').toUpperCase();
}

function fmt(n) {
  if (n == null || Number.isNaN(n)) return '';
  if (n >= 1e9) return `${(n / 1e9).toFixed(1).replace('.0', '')} млрд`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(1).replace('.0', '')} млн`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1).replace('.0', '')} тыс.`;
  return String(n);
}

function initials(name) {
  return String(name || '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() || '')
    .join('');
}

function shortVersion(version) {
  if (!version) return '—';
  return version.length > 10 ? version.slice(0, 8) : version;
}

function activeAccount() {
  return state.accounts.find((a) => a.id === state.activeAccountId) || state.accounts[0] || null;
}

function modeTitle(mode = state.launchMode) {
  return LAUNCH_MODES.find((m) => m.id === mode)?.title || 'Авто';
}

function protocolTitle(protocol = clients.protocol) {
  const map = { roblox: 'официальный Roblox', fishstrap: 'Fishstrap', bloxstrap: 'Bloxstrap', other: 'другое приложение', none: 'не зарегистрирован' };
  return map[protocol?.kind] || 'неизвестно';
}

function toast(message, kind = 'info') {
  const host = $('#toasts');
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.innerHTML = `<span class="t-ico"></span><span>${esc(message)}</span>`;
  host.appendChild(node);
  setTimeout(() => {
    node.classList.add('is-out');
    setTimeout(() => node.remove(), 240);
  }, 3800);
}

/* ------------------------------- запуск -------------------------------- */

async function boot() {
  const params = new URLSearchParams(location.search);
  const requestedView = params.get('view');
  if (['home', 'search', 'friends', 'accounts', 'skins', 'settings'].includes(requestedView)) view = requestedView;

  const data = await api.getState();
  state = data.state;
  clients = data.clients;
  applyAppearance();
  render();
  hydrateGames();
  loadRecommendations();
  refreshFriends();

  api.onInstallProgress?.((payload) => {
    ui.installP = payload;
    updateInstallDom();
  });
}

function applyAppearance() {
  const root = document.documentElement;
  root.dataset.theme = state.theme;
  root.dataset.bg = state.background || 'aurora';
  root.dataset.motion = state.reduceMotion ? 'off' : 'on';
  const accent = ACCENTS.find((a) => a.id === state.accent) || ACCENTS[0];
  root.style.setProperty('--accent-a', accent.a);
  root.style.setProperty('--accent-b', accent.b);
}

async function save(patch) {
  state = await api.saveState(patch);
  applyAppearance();
  return state;
}

/* ------------------------------- рендер -------------------------------- */

function render() {
  renderNav();
  const content = $('#content');
  const html =
    view === 'search' ? renderSearch() :
    view === 'friends' ? renderFriends() :
    view === 'accounts' ? renderAccounts() :
    view === 'skins' ? renderSkins() :
    view === 'settings' ? renderSettings() :
    renderHome();
  content.innerHTML = html;
  renderSideStatus();
  if (view === 'settings') updateInstallDom();
}

function renderNav() {
  const counts = { home: state.games.length, friends: state.friends?.length || 0, accounts: state.accounts.length };
  $('#nav').innerHTML = NAV.map((item) => {
    const active = view === item.id;
    const count = counts[item.id];
    return `
      <button class="nav-item ${active ? 'is-active' : ''}" data-action="navigate" data-view="${item.id}" ${active ? 'aria-current="page"' : ''}>
        <svg viewBox="0 0 24 24">${item.icon}</svg>
        <span>${item.label}</span>
        ${count ? `<span class="nav-badge">${count}</span>` : ''}
      </button>`;
  }).join('');
}

function renderSideStatus() {
  const rbx = clients.roblox || {};
  $('#side-status').innerHTML = `
    <div class="status-row"><span class="dot ${rbx.installed ? 'ok' : 'warn'}"></span><span>Roblox <b>${rbx.installed ? 'готов' : 'нет'}</b></span></div>
    <div class="status-row"><span class="dot ${rbx.installed ? 'ok' : 'warn'}"></span><span>${esc(modeTitle())}</span></div>`;
}

/* -------------------------------- главная ------------------------------ */

function renderHome() {
  const featured = state.games.find((g) => g.placeId === state.featuredPlaceId) || state.games[0] || null;
  const account = activeAccount();

  return `
    <section class="view">
      ${renderHero(featured)}
      <div class="home-grid">
        <div class="home-main">
          <div class="section-head">
            <h2>Избранное <span class="muted tiny">${state.games.length}</span></h2>
            <div class="row">
              <button class="btn btn-soft btn-sm" data-action="refresh-all">Обновить</button>
              <button class="btn btn-ghost btn-sm" data-action="add-game">+ Добавить игру</button>
            </div>
          </div>
          <div class="games-grid">
            ${state.games.map((game, index) => renderGameCard(game, index)).join('')}
            <button class="game-add" data-action="add-game">
              <span class="plus">+</span>
              <span>Добавить игру</span>
            </button>
          </div>
          ${renderRecommendations()}
        </div>
        <aside class="home-rail">
          ${renderAccountRail(account)}
          ${renderSkinRail()}
          ${renderClientRail()}
        </aside>
      </div>
    </section>`;
}

function renderHero(game) {
  if (!game) {
    return `
      <div class="hero no-art" style="--hue:262">
        <div class="hero-bg"></div>
        <div class="hero-scrim"></div>
        <div class="hero-inner">
          <div class="hero-eyebrow"><span class="spark"></span>GaraBlox</div>
          <h1 class="hero-title">Добавь первую игру</h1>
          <div class="hero-meta">Твои любимые миры будут запускаться в один клик</div>
          <div class="hero-actions">
            <button class="btn btn-primary btn-play" data-action="add-game">Добавить игру</button>
          </div>
        </div>
      </div>`;
  }

  const art = game.bannerUrl || game.iconUrl || '';
  const meta = [
    game.creator ? esc(game.creator) : '',
    game.playing != null ? `${fmt(game.playing)} играют` : '',
    game.visits != null ? `${fmt(game.visits)} визитов` : ''
  ].filter(Boolean);

  return `
    <div class="hero ${game.iconUrl ? 'has-art' : 'no-art'}" ${artStyle(art, hueFor(game))}>
      <div class="hero-bg"></div>
      <div class="hero-scrim"></div>
      <div class="hero-inner">
        <div class="hero-eyebrow"><span class="spark"></span>Любимая игра</div>
        <h1 class="hero-title">${esc(game.name)}</h1>
        <div class="hero-meta">
          ${meta.map((part) => `<span>${part}</span>`).join('<span class="sep"></span>')}
        </div>
        <div class="hero-actions">
          <button class="btn btn-primary btn-play" data-action="play" data-place="${game.placeId}">
            <svg class="ico-play" viewBox="0 0 24 24"><path d="M8 5.2v13.6L19 12z"/></svg>
            Играть
          </button>
          <button class="btn btn-ghost" data-action="open-page" data-place="${game.placeId}">Страница игры</button>
        </div>
      </div>
    </div>`;
}

function renderGameCard(game, index) {
  const art = game.bannerUrl || game.iconUrl || '';
  const artMode = game.bannerUrl ? 'has-banner' : game.iconUrl ? 'icon-only' : 'no-art';
  const isFeatured = game.placeId === state.featuredPlaceId;
  const sub = [game.creator, game.playing != null ? `${fmt(game.playing)} играют` : ''].filter(Boolean).join(' · ') || 'Roblox';

  return `
    <article class="game-card" role="button" tabindex="0" data-action="play" data-place="${game.placeId}"
             style="animation-delay:${Math.min(index, 12) * 28}ms" aria-label="Играть в ${esc(game.name)}">
      <div class="game-art ${artMode}" ${artStyle(art, hueFor(game))}>
        <span class="art-mono">${esc(monogram(game.name))}</span>
        <div class="art-layer"></div>
        ${isFeatured ? '<span class="game-fav">любимая</span>' : ''}
        <div class="game-tools">
          <button class="icon-btn ${isFeatured ? 'is-fav' : ''}" data-action="feature" data-place="${game.placeId}" title="Сделать любимой" aria-label="Сделать любимой">
            <svg viewBox="0 0 24 24"><path d="M12 4.6l2.3 4.7 5.2.8-3.8 3.7.9 5.2-4.6-2.5-4.6 2.5.9-5.2L4.5 10l5.2-.8z"/></svg>
          </button>
          <button class="icon-btn" data-action="remove" data-place="${game.placeId}" title="Убрать из избранного" aria-label="Убрать">
            <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
          </button>
        </div>
        <div class="game-play"><svg viewBox="0 0 24 24"><path d="M8 5.2v13.6L19 12z"/></svg></div>
      </div>
      <div class="game-body">
        <div class="game-name">${esc(game.name)}</div>
        <div class="game-sub">${esc(sub)}</div>
      </div>
    </article>`;
}

function renderAccountRail(account) {
  if (!account) return '';
  return `
    <div class="card">
      <div class="card-head">
        <span class="card-title">Аккаунт</span>
        <span class="badge">профиль</span>
      </div>
      <div class="account-mini">
        <div class="avatar" style="background:${esc(account.color)}">${esc(initials(account.name))}</div>
        <div class="who">
          <b>${esc(account.name)}</b>
          <span>${esc(account.note || 'без заметки')}</span>
        </div>
      </div>
      <div class="card-actions">
        <button class="btn btn-soft btn-sm" data-action="navigate" data-view="accounts">Профили</button>
        <button class="btn btn-soft btn-sm" data-action="open-avatar">Аватар</button>
      </div>
    </div>`;
}

function renderSkinRail() {
  const theme = THEMES.find((t) => t.id === state.theme) || THEMES[0];
  return `
    <div class="card">
      <div class="card-head">
        <span class="card-title">Скин лаунчера</span>
        <button class="btn btn-soft btn-sm" data-action="navigate" data-view="skins">Все</button>
      </div>
      <div class="theme-dots">
        ${THEMES.map((item) => `
          <button class="theme-dot ${state.theme === item.id ? 'is-active' : ''}" style="--dot:${item.dot}"
                  data-action="set-theme" data-theme-id="${item.id}" title="${item.name}" aria-label="${item.name}"><i></i></button>`).join('')}
      </div>
      <p class="tiny muted" style="margin:10px 0 0">${theme.name} — меняется только оформление лаунчера, клиент Roblox не трогаем.</p>
    </div>`;
}

function renderClientRail() {
  const rbx = clients.roblox || {};
  return `
    <div class="card">
      <div class="card-head">
        <span class="card-title">Клиент</span>
        <span class="badge ${rbx.installed ? 'ok' : 'warn'}">${rbx.installed ? 'готов' : 'нет'}</span>
      </div>
      <div class="status-line"><span class="label">Roblox</span><span class="value">${rbx.installed ? `v${esc(shortVersion(rbx.version))}` : 'не установлен'}</span></div>
      <div class="status-line"><span class="label">Запуск</span><span class="value">${esc(modeTitle())}</span></div>
      <div class="status-line"><span class="label">Обработчик</span><span class="value">${esc(protocolTitle())}</span></div>
      <div class="card-actions">
        <button class="btn btn-ghost btn-sm btn-block" data-action="navigate" data-view="settings">Настройки клиента</button>
      </div>
    </div>`;
}

/* ------------------------------- поиск --------------------------------- */

function sortLabel(sort) {
  return SORT_LABELS[sort.id] || sort.name || sort.id;
}

function renderSkeletons(count = 4) {
  return Array.from({ length: count }, () => `
    <div class="skeleton" aria-hidden="true">
      <div class="sk-art"></div>
      <div class="sk-line" style="width:70%"></div>
      <div class="sk-line" style="width:45%"></div>
    </div>`).join('');
}

function renderDiscoverCard(game, index = 0) {
  const icon = game.iconUrl || '';
  const inLibrary = state.games.some((item) => item.placeId === game.placeId);
  const sub = [
    game.creator || game.genre,
    game.playing != null ? `${fmt(game.playing)} играют` : ''
  ].filter(Boolean).join(' · ') || 'Roblox';

  return `
    <article class="game-card" role="button" tabindex="0" data-action="play" data-place="${game.placeId}"
             style="animation-delay:${Math.min(index, 12) * 24}ms" aria-label="Играть в ${esc(game.name)}">
      <div class="game-art ${icon ? 'icon-only' : 'no-art'}" ${artStyle(icon, hueFor(game))}>
        <span class="art-mono">${esc(monogram(game.name))}</span>
        <div class="art-layer"></div>
        <div class="game-tools">
          <button class="icon-btn ${inLibrary ? 'is-fav' : ''}" data-action="quick-add" data-place="${game.placeId}"
                  title="${inLibrary ? 'Уже в избранном' : 'В избранное'}" aria-label="В избранное">
            <svg viewBox="0 0 24 24"><path d="${inLibrary ? 'M5 12.5l4.5 4.5L19 7' : 'M12 5v14M5 12h14'}"/></svg>
          </button>
        </div>
        <div class="game-play"><svg viewBox="0 0 24 24"><path d="M8 5.2v13.6L19 12z"/></svg></div>
      </div>
      <div class="game-body">
        <div class="game-name">${esc(game.name)}</div>
        <div class="game-sub">${esc(sub)}</div>
      </div>
    </article>`;
}

function renderRecommendations(limit = 8) {
  const recs = ui.recs;
  const sorts = recs.sorts.length ? recs.sorts : [{ id: 'top-trending', name: 'Top Trending' }];
  const games = recs.games.slice(0, limit);

  return `
    <div class="section-head" style="margin-top:28px">
      <h2>Рекомендации <span class="muted tiny">${recs.loading ? '…' : games.length}</span></h2>
      <button class="btn btn-soft btn-sm" data-action="refresh-recs">Обновить</button>
    </div>
    <div class="chips">
      ${sorts.map((sort) => `
        <button class="chip ${recs.active === sort.id ? 'is-active' : ''}" data-action="set-sort" data-sort="${esc(sort.id)}">
          ${esc(sortLabel(sort))}
        </button>`).join('')}
    </div>
    <div class="games-grid">
      ${recs.loading
        ? renderSkeletons(limit)
        : recs.error
          ? `<div class="notice" style="grid-column:1/-1"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.2v.4"/></svg><div>Не удалось загрузить рекомендации: ${esc(recs.error)}</div></div>`
          : games.map(renderDiscoverCard).join('')}
    </div>`;
}

function renderSearch() {
  const s = ui.search;
  return `
    <section class="view">
      <div class="page-head">
        <div>
          <h1>Поиск игр</h1>
          <p>Каталог Roblox: ищи по названию и запускай сразу из лаунчера.</p>
        </div>
      </div>

      <form class="searchbar" id="search-form" autocomplete="off">
        <svg class="sb-icon" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.4"/><path d="M15.7 15.7 20 20"/></svg>
        <input id="search-input" class="sb-input" value="${esc(s.query)}" placeholder="Например: Blox Fruits, obby, tycoon" />
        <button class="btn btn-primary" type="submit" ${s.loading ? 'disabled' : ''}>${s.loading ? 'Ищу…' : 'Найти'}</button>
      </form>

      ${renderSearchBody()}
    </section>`;
}

function renderSearchBody() {
  const s = ui.search;

  if (!s.ran) {
    return `
      <div class="section-head">
        <h2>Популярное сейчас</h2>
        <span class="muted tiny">пока ничего не искали</span>
      </div>
      <div class="games-grid">
        ${ui.recs.loading ? renderSkeletons(8) : ui.recs.games.slice(0, 8).map(renderDiscoverCard).join('')}
      </div>`;
  }

  if (s.error) {
    return `<div class="notice"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.2v.4"/></svg>
      <div>Поиск не удался: ${esc(s.error)}. Проверь интернет и попробуй снова.</div></div>`;
  }

  if (s.loading && !s.games.length) {
    return `<div class="section-head"><h2>Ищу «${esc(s.query)}»…</h2></div><div class="games-grid">${renderSkeletons(8)}</div>`;
  }

  if (!s.games.length) {
    return `<div class="notice"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.2v.4"/></svg>
      <div>По запросу «${esc(s.query)}» ничего не нашлось. Попробуй короче или на английском.</div></div>`;
  }

  return `
    <div class="section-head">
      <h2>Результаты «${esc(s.query)}» <span class="muted tiny">${s.games.length}</span></h2>
    </div>
    <div class="games-grid">${s.games.map(renderDiscoverCard).join('')}</div>
    ${s.next ? `<div class="load-more"><button class="btn btn-ghost" data-action="search-more" ${s.loading ? 'disabled' : ''}>
      ${s.loading ? 'Загружаю…' : 'Показать ещё'}
    </button></div>` : ''}`;
}

/* ------------------------------- друзья -------------------------------- */

function friendColor(id) {
  return ACCOUNT_COLORS[Math.abs(Number(id) || 0) % ACCOUNT_COLORS.length];
}

function renderFriendAvatar(friend, size = 'md') {
  const label = initials(friend.displayName || friend.name);
  return `
    <div class="friend-avatar ${size}" style="--av:${friend.avatarUrl ? cssUrl(friend.avatarUrl) : 'none'};background:${friendColor(friend.id)}">
      <span>${esc(label)}</span>
      ${friend.avatarUrl ? '<i class="av-img"></i>' : ''}
    </div>`;
}

function renderFriendCard(friend, index = 0) {
  return `
    <article class="friend-card" style="animation-delay:${Math.min(index, 12) * 24}ms">
      ${renderFriendAvatar(friend)}
      <div class="friend-meta">
        <b>${esc(friend.displayName || friend.name)}</b>
        <span>@${esc(friend.name)}</span>
      </div>
      <div class="friend-actions">
        <button class="btn btn-soft btn-sm" data-action="open-profile" data-user="${friend.id}">Профиль</button>
        <button class="btn btn-danger btn-sm" data-action="remove-friend" data-id="${friend.id}">Убрать</button>
      </div>
    </article>`;
}

function renderFriends() {
  const friends = state.friends || [];
  return `
    <section class="view">
      <div class="page-head">
        <div>
          <h1>Друзья</h1>
          <p>Быстрая книжка контактов: сохраняй ники и открывай профили в один клик.</p>
        </div>
        <button class="btn btn-ghost" data-action="friends-site">Друзья на сайте</button>
      </div>

      <div class="notice" style="margin-bottom:16px">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8.2v.6M12 11v5"/></svg>
        <div>
          Roblox не отдаёт список друзей и онлайн-статусы без входа в аккаунт, поэтому здесь — локальная книжка контактов.
          Добавляй ники, чтобы быстро открывать профили и играть вместе через официальный клиент.
        </div>
      </div>

      <form class="searchbar" id="friend-form" autocomplete="off">
        <svg class="sb-icon" viewBox="0 0 24 24"><circle cx="10.5" cy="8.5" r="3.4"/><path d="M4.6 19c.6-3.4 3-5.2 5.9-5.2s5.3 1.8 5.9 5.2"/><path d="M17.5 8.5h4M19.5 6.5v4"/></svg>
        <input id="friend-input" class="sb-input" placeholder="Ник в Roblox, например builderman" />
        <button class="btn btn-primary" type="submit">Добавить</button>
      </form>

      ${friends.length
        ? `<div class="friends-grid">${friends.map(renderFriendCard).join('')}</div>`
        : `<div class="empty-state">
             <div class="empty-icon">🧑‍🤝‍🧑</div>
             <h3>Пока никого нет</h3>
             <p class="muted">Введи ник друга сверху — сохраню его локально и покажу кнопку «Профиль».</p>
           </div>`}
    </section>`;
}

/* ------------------------------- аккаунты ------------------------------ */

function renderAccounts() {
  return `
    <section class="view">
      <div class="page-head">
        <div>
          <h1>Аккаунты</h1>
          <p>Профили-пометки для порядка. Пароли и cookies лаунчер не хранит — вход выполняется в официальном клиенте.</p>
        </div>
        <div class="row">
          <button class="btn btn-ghost" data-action="open-roblox-app">Открыть Roblox</button>
          <button class="btn btn-primary" data-action="add-account">+ Профиль</button>
        </div>
      </div>

      <div class="notice" style="margin-bottom:16px">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8.2v.6M12 11v5"/></svg>
        <div>
          Переключение аккаунта делается руками в самом Roblox: выйди из одного и войди в другой.
          GaraBlox только запоминает, какой профиль ты сейчас считаешь активным, чтобы не путаться в любимых играх.
          Никакой подмены сессии, обхода банов или автологина здесь нет и не будет.
        </div>
      </div>

      <div class="accounts-grid">
        ${state.accounts.map(renderAccountCard).join('')}
        <button class="game-add" data-action="add-account" style="min-height:132px">
          <span class="plus">+</span><span>Новый профиль</span>
        </button>
      </div>

      <div class="stack" style="margin-top:18px">
        <div class="panel">
          <div class="panel-head">
            <div>
              <h3>Внешний вид персонажа</h3>
              <p>Скины персонажа меняются на официальном сайте Roblox — это надёжнее и не нарушает правила.</p>
            </div>
          </div>
          <div class="row">
            <button class="btn btn-ghost" data-action="open-avatar">Редактор аватара</button>
            <button class="btn btn-ghost" data-action="open-catalog">Каталог Roblox</button>
          </div>
        </div>
      </div>
    </section>`;
}

function renderAccountCard(account) {
  const active = account.id === state.activeAccountId;
  return `
    <article class="account-card ${active ? 'is-active' : ''}">
      <div class="ac-top">
        <div class="avatar" style="background:${esc(account.color)}">${esc(initials(account.name))}</div>
        <div style="min-width:0;flex:1">
          <div class="ac-name">${esc(account.name)}</div>
          <div class="ac-note">${esc(account.note || 'без заметки')}</div>
        </div>
        ${active ? '<span class="badge ok">активный</span>' : ''}
      </div>
      <div class="ac-actions">
        ${active ? '' : `<button class="btn btn-soft btn-sm" data-action="set-account" data-id="${esc(account.id)}">Выбрать</button>`}
        <button class="btn btn-soft btn-sm" data-action="edit-account" data-id="${esc(account.id)}">Изменить</button>
        ${state.accounts.length > 1 ? `<button class="btn btn-danger btn-sm" data-action="delete-account" data-id="${esc(account.id)}">Удалить</button>` : ''}
      </div>
    </article>`;
}

/* -------------------------------- скины -------------------------------- */

function renderSkins() {
  return `
    <section class="view">
      <div class="page-head">
        <div>
          <h1>Скины</h1>
          <p>Оформление самого лаунчера: тема, акцент и фон. Клиент Roblox при этом не изменяется.</p>
        </div>
      </div>

      <div class="panel" style="margin-bottom:16px">
        <div class="panel-head"><div><h3>Тема</h3><p>Полная палитра интерфейса.</p></div></div>
        <div class="theme-grid">
          ${THEMES.map((theme) => {
            const active = state.theme === theme.id;
            return `
              <button class="theme-card ${active ? 'is-active' : ''}" data-action="set-theme" data-theme-id="${theme.id}"
                      aria-label="Тема ${theme.name}">
                <div class="theme-preview" style="--tp-bg:${theme.bg};--tp-surface:${theme.surface};--tp-accent:${theme.accent}">
                  <div class="tp-side"></div>
                  <div class="tp-main">
                    <div class="tp-hero"></div>
                    <div class="tp-rows"><div class="tp-row"></div><div class="tp-row"></div></div>
                  </div>
                </div>
                <div class="theme-body">
                  <div><b>${theme.name}</b><br /><span>${theme.sub}</span></div>
                  ${active ? '<span class="badge ok">выбрана</span>' : ''}
                </div>
              </button>`;
          }).join('')}
        </div>
      </div>

      <div class="panel" style="margin-bottom:16px">
        <div class="panel-head"><div><h3>Акцент</h3><p>Градиент кнопок, активных пунктов и подсветки.</p></div></div>
        <div class="accents">
          ${ACCENTS.map((accent) => `
            <button class="accent-dot ${state.accent === accent.id ? 'is-active' : ''}"
                    style="--sw:linear-gradient(135deg,${accent.a},${accent.b})"
                    data-action="set-accent" data-accent="${accent.id}"
                    title="${accent.name}" aria-label="${accent.name}"></button>`).join('')}
        </div>
      </div>

      <div class="panel">
        <div class="panel-head"><div><h3>Фон и анимации</h3><p>Мелочи, которые влияют на настроение.</p></div></div>
        <div class="option-grid" style="margin-bottom:6px">
          ${[
            { id: 'aurora', title: 'Свечение', sub: 'мягкие градиентные пятна' },
            { id: 'plain', title: 'Чистый', sub: 'ровный фон без декора' },
            { id: 'grid', title: 'Сетка', sub: 'техно-сетка поверх свечения' }
          ].map((bg) => `
            <button class="option ${state.background === bg.id ? 'is-active' : ''}" data-action="set-bg" data-bg-id="${bg.id}">
              <span class="opt-title">${bg.title}</span>
              <span class="opt-sub">${bg.sub}</span>
            </button>`).join('')}
        </div>
        <div class="setting-row">
          <div class="sr-text">
            <b>Снизить анимации</b>
            <span>Отключает плавные переходы и появление карточек</span>
          </div>
          <button class="switch" role="switch" aria-checked="${state.reduceMotion ? 'true' : 'false'}"
                  data-action="toggle-motion" aria-label="Снизить анимации"></button>
        </div>
      </div>
    </section>`;
}

/* ------------------------------ настройки ------------------------------ */

function renderSettings() {
  const rbx = clients.roblox || {};
  const protocol = clients.protocol || {};

  return `
    <section class="view">
      <div class="page-head">
        <div>
          <h1>Настройки</h1>
          <p>Клиент, установка и то, как именно открываются игры.</p>
        </div>
        <button class="btn btn-ghost" data-action="refresh-clients">Проверить клиентов</button>
      </div>

      <div class="stack">
        <div class="panel">
          <div class="panel-head">
            <div>
              <h3>Способ запуска</h3>
              <p>Игра открывается ссылкой <span class="soft">roblox://experiences/start?placeId=…</span>. Если выбрать Fishstrap или Bloxstrap,
                 лаунчер запустит их напрямую и передаст ссылку — так же, как это делает ярлык на рабочем столе.</p>
            </div>
          </div>
          <div class="option-grid">
            ${LAUNCH_MODES.map(renderModeOption).join('')}
          </div>
          ${state.launchMode === 'roblox' && protocol.kind !== 'roblox' ? `
            <div class="install-note">
              Сейчас ссылки roblox:// открывает ${esc(protocolTitle(protocol))}. Чтобы игра шла через официальный клиент,
              переключи обработчик протокола в настройках Fishstrap/Bloxstrap.
            </div>` : ''}
          ${state.launchMode === 'fishstrap' && protocol.kind !== 'fishstrap' && clients.fishstrap?.installed ? `
            <div class="install-note">
              Fishstrap найден, но обработчик roblox:// — ${esc(protocolTitle(protocol))}. Лаунчер запустит Fishstrap.exe напрямую с параметром -player.
            </div>` : ''}
          ${state.launchMode === 'custom' ? `
            <div class="setting-row">
              <div class="sr-text">
                <b>Свой клиент</b>
                <span>${state.customClientPath ? esc(state.customClientPath) : 'файл не выбран'}</span>
              </div>
              <button class="btn btn-soft btn-sm" data-action="pick-client">Выбрать .exe</button>
            </div>` : ''}
        </div>

        <div class="panel">
          <div class="panel-head">
            <div><h3>Найденные клиенты</h3><p>Что GaraBlox видит в системе прямо сейчас.</p></div>
          </div>
          <div class="status-line">
            <span class="label">Roblox Player</span>
            <span class="value">${rbx.installed ? `версия ${esc(shortVersion(rbx.version))}` : '<span class="badge warn">не установлен</span>'}</span>
          </div>
          ${rbx.path ? `<div class="tiny muted" style="padding-bottom:9px;word-break:break-all">${esc(rbx.path)}</div>` : ''}
          <div class="status-line">
            <span class="label">Fishstrap</span>
            <span class="value">${clients.fishstrap?.installed ? `найден` : '<span class="badge warn">не найден</span>'}</span>
          </div>
          ${clients.fishstrap?.path ? `<div class="tiny muted" style="padding-bottom:9px;word-break:break-all">${esc(clients.fishstrap.path)}</div>` : ''}
          <div class="status-line">
            <span class="label">Bloxstrap</span>
            <span class="value">${clients.bloxstrap?.installed ? `найден` : '<span class="badge warn">не найден</span>'}</span>
          </div>
          ${clients.bloxstrap?.path ? `<div class="tiny muted" style="padding-bottom:9px;word-break:break-all">${esc(clients.bloxstrap.path)}</div>` : ''}
          <div class="status-line">
            <span class="label">Обработчик roblox://</span>
            <span class="value">${esc(protocolTitle(protocol))}</span>
          </div>
          ${protocol.exe ? `<div class="tiny muted" style="word-break:break-all">${esc(protocol.exe)}</div>` : ''}
        </div>

        <div class="panel">
          <div class="panel-head">
            <div>
              <h3>Установка Roblox</h3>
              <p>Лаунчер скачивает официальный установщик с roblox.com и ставит его в тихом режиме. Никаких сторонних сборок.</p>
            </div>
            <button class="btn btn-primary" data-action="install-roblox" ${ui.installing ? 'disabled' : ''}>
              ${rbx.installed ? 'Переустановить' : 'Скачать и установить'}
            </button>
          </div>
          <div class="status-line">
            <span class="label">Статус</span>
            <span class="value">${rbx.installed ? '<span class="badge ok">установлен</span>' : '<span class="badge warn">не установлен</span>'}</span>
          </div>
          <div class="progress ${ui.installing && !ui.installP?.percent ? 'is-indeterminate' : ''}" id="install-progress" ${ui.installing ? '' : 'hidden'}>
            <i style="width:${ui.installP?.percent ? Math.min(100, ui.installP.percent) : 0}%"></i>
          </div>
          <div class="install-note" id="install-note">${esc(ui.installP?.message || '')}</div>
        </div>

        <div class="panel">
          <div class="panel-head"><div><h3>Прочее</h3><p>Данные лаунчера и анимации.</p></div></div>
          <div class="setting-row">
            <div class="sr-text">
              <b>Снизить анимации</b>
              <span>Меньше движения в интерфейсе</span>
            </div>
            <button class="switch" role="switch" aria-checked="${state.reduceMotion ? 'true' : 'false'}"
                    data-action="toggle-motion" aria-label="Снизить анимации"></button>
          </div>
          <div class="setting-row">
            <div class="sr-text">
              <b>Папка с настройками</b>
              <span>Список игр, профили и тема лежат в JSON-файле</span>
            </div>
            <button class="btn btn-soft btn-sm" data-action="open-state-folder">Открыть</button>
          </div>
          <div class="setting-row">
            <div class="sr-text">
              <b>Лог запусков</b>
              <span>Что именно лаунчер передал клиенту — для диагностики</span>
            </div>
            <button class="btn btn-soft btn-sm" data-action="open-log">Открыть</button>
          </div>
          <div class="setting-row">
            <div class="sr-text">
              <b>Сбросить лаунчер</b>
              <span>Вернуть стандартные игры, профили и тему</span>
            </div>
            <button class="btn btn-danger btn-sm" data-action="reset-state">Сбросить</button>
          </div>
        </div>

        <div class="panel">
          <p class="tiny muted" style="margin:0;line-height:1.6">
            GaraBlox — неофициальная оболочка. Она не изменяет файлы Roblox, не вмешивается в авторизацию и не обходит античит.
            Использование сторонних лаунчеров может нарушать правила Roblox — запускай на свой риск.
          </p>
        </div>
      </div>
    </section>`;
}

function renderModeOption(mode) {
  const active = state.launchMode === mode.id;
  const status = modeStatus(mode.id);
  return `
    <button class="option ${active ? 'is-active' : ''}" data-action="set-mode" data-mode="${mode.id}">
      <span class="opt-title">${mode.title}<span class="dot ${status.ok ? 'ok' : 'warn'}" style="margin-left:auto"></span></span>
      <span class="opt-sub">${mode.sub}</span>
      <span class="opt-state">${esc(status.text)}</span>
    </button>`;
}

function modeStatus(id) {
  const rbx = clients.roblox?.installed;
  const fish = clients.fishstrap?.installed;
  const blox = clients.bloxstrap?.installed;
  if (id === 'auto') return { ok: Boolean(rbx), text: `сейчас: ${protocolTitle()}` };
  if (id === 'roblox') return { ok: Boolean(rbx), text: rbx ? 'клиент установлен' : 'клиент не установлен' };
  if (id === 'fishstrap') return { ok: Boolean(fish), text: fish ? 'найден в системе' : 'не найден' };
  if (id === 'bloxstrap') return { ok: Boolean(blox), text: blox ? 'найден в системе' : 'не найден' };
  return { ok: Boolean(state.customClientPath), text: state.customClientPath ? 'путь указан' : 'выбери .exe' };
}

function updateInstallDom() {
  const bar = $('#install-progress');
  const note = $('#install-note');
  if (!bar || !note) return;
  const p = ui.installP;
  bar.hidden = !ui.installing;
  if (!ui.installing) return;
  if (p?.percent == null) {
    bar.classList.add('is-indeterminate');
    bar.querySelector('i').style.width = '38%';
  } else {
    bar.classList.remove('is-indeterminate');
    bar.querySelector('i').style.width = `${Math.min(100, p.percent)}%`;
  }
  const text =
    p?.phase === 'download' ? `Скачиваю установщик… ${p.percent ? `${Math.round(p.percent)}%` : ''}` :
    p?.message || 'Работаю…';
  note.textContent = text;
}

/* ------------------------------- действия ------------------------------ */

document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-action]');
  if (!target) return;
  handleAction(target.dataset.action, target, event).catch((err) => {
    console.error(err);
    toast(err?.message || 'Что-то пошло не так', 'err');
  });
});

document.addEventListener('submit', (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  if (form.id === 'search-form') {
    event.preventDefault();
    runSearch().catch((err) => toast(err.message, 'err'));
  }
  if (form.id === 'friend-form') {
    event.preventDefault();
    addFriendFromForm(form).catch((err) => toast(err.message, 'err'));
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !$('#modal-root').hidden) closeModal();
  if (event.key === 'Enter' || event.key === ' ') {
    const card = event.target.closest?.('.game-card');
    if (card && event.target === card) {
      event.preventDefault();
      playGame(Number(card.dataset.place));
    }
  }
});

async function handleAction(action, el, event) {
  switch (action) {
    case 'win-min': return api.minimize();
    case 'win-max': return api.toggleMaximize();
    case 'win-close': return api.close();

    case 'navigate': {
      const next = el.dataset.view;
      if (!next || next === view) return;
      view = next;
      render();
      $('#content').scrollTop = 0;
      return;
    }

    case 'set-theme': {
      await save({ theme: el.dataset.themeId });
      render();
      return;
    }

    case 'set-accent': {
      await save({ accent: el.dataset.accent });
      render();
      return;
    }

    case 'set-bg': {
      await save({ background: el.dataset.bgId });
      render();
      return;
    }

    case 'toggle-motion': {
      await save({ reduceMotion: !state.reduceMotion });
      render();
      return;
    }

    case 'set-mode': {
      const mode = el.dataset.mode;
      await save({ launchMode: mode });
      if (mode === 'custom' && !state.customClientPath) {
        const picked = await api.pickClient();
        if (picked) {
          const data = await api.getState();
          clients = data.clients;
        }
      }
      render();
      if (mode !== 'auto' && mode !== 'roblox' && !modeStatus(mode).ok) {
        toast('Этот клиент не найден — можно выбрать свой .exe', 'err');
      }
      return;
    }

    case 'pick-client': {
      const picked = await api.pickClient();
      if (picked) {
        toast('Клиент выбран', 'ok');
        const data = await api.getState();
        state = data.state;
        clients = data.clients;
        render();
      }
      return;
    }

    case 'refresh-clients': {
      clients = await api.detectClients();
      render();
      toast('Проверил клиентов заново');
      return;
    }

    case 'install-roblox': return installRoblox();

    case 'add-game': return openAddGameModal();
    case 'play': {
      if (event?.target?.closest?.('[data-action="feature"], [data-action="remove"]')) return;
      return playGame(Number(el.dataset.place));
    }
    case 'feature': {
      const id = Number(el.dataset.place);
      await api.featureGame(id);
      state.featuredPlaceId = id;
      render();
      toast('Любимая игра обновлена');
      return;
    }
    case 'remove': {
      const id = Number(el.dataset.place);
      const game = state.games.find((g) => g.placeId === id);
      openConfirm(`Убрать «${game?.name || 'игру'}» из избранного?`, 'Игра останется в Roblox — просто исчезнет из лаунчера.', async () => {
        state = await api.removeGame(id);
        render();
        toast('Убрано из избранного');
      });
      return;
    }
    case 'open-page': {
      await api.openGamePage(Number(el.dataset.place));
      return;
    }
    case 'refresh-all': return refreshAll();

    case 'search-more': return runSearch(ui.search.next);
    case 'set-sort': return loadRecommendations(el.dataset.sort);
    case 'refresh-recs': return loadRecommendations();

    case 'quick-add': {
      const id = Number(el.dataset.place);
      if (state.games.some((game) => game.placeId === id)) {
        toast('Эта игра уже в избранном');
        return;
      }
      const result = await api.addGame(id);
      upsertLocal(result.game);
      render();
      toast(`Добавил: ${result.game.name}`, 'ok');
      return;
    }

    case 'remove-friend': {
      const friend = (state.friends || []).find((item) => String(item.id) === String(el.dataset.id));
      openConfirm(`Убрать «${friend?.displayName || friend?.name || 'друга'}» из списка?`, 'Это только локальная запись — в Roblox ничего не изменится.', async () => {
        state.friends = await api.removeFriend(el.dataset.id);
        render();
        toast('Убрал из списка');
      });
      return;
    }

    case 'open-profile': return api.openExternal(`https://www.roblox.com/users/${encodeURIComponent(el.dataset.user)}/profile`);
    case 'friends-site': return api.openExternal('https://www.roblox.com/users/friends');
    case 'open-log': {
      const file = await api.openLog();
      toast(`Открыл лог: ${file}`);
      return;
    }

    case 'add-account': return openAccountModal(null);
    case 'edit-account': return openAccountModal(el.dataset.id);
    case 'set-account': {
      await save({ activeAccountId: el.dataset.id });
      render();
      toast('Активный профиль переключён');
      return;
    }
    case 'delete-account': {
      const account = state.accounts.find((a) => a.id === el.dataset.id);
      openConfirm(`Удалить профиль «${account?.name || ''}»?`, 'Это только пометка в лаунчере, аккаунт Roblox не пострадает.', async () => {
        const accounts = state.accounts.filter((a) => a.id !== el.dataset.id);
        const patch = { accounts };
        if (state.activeAccountId === el.dataset.id) patch.activeAccountId = accounts[0]?.id ?? null;
        await save(patch);
        render();
        toast('Профиль удалён');
      });
      return;
    }

    case 'open-avatar': return api.openExternal('https://www.roblox.com/my/avatar');
    case 'open-catalog': return api.openExternal('https://www.roblox.com/catalog');
    case 'open-roblox-app': return openRobloxApp();

    case 'open-state-folder': {
      const p = await api.openStateFolder();
      toast(`Открыл папку: ${p}`);
      return;
    }
    case 'reset-state': {
      openConfirm('Сбросить лаунчер?', 'Игры, профили и оформление вернутся к стандартным.', async () => {
        state = await api.resetState();
        applyAppearance();
        view = 'home';
        render();
        toast('Лаунчер сброшен', 'ok');
      });
      return;
    }

    case 'close-modal': return closeModal();
    case 'confirm-yes': {
      const fn = ui.pendingConfirm;
      ui.pendingConfirm = null;
      closeModal();
      if (fn) await fn();
      return;
    }
    case 'submit-game': return submitGame();
    case 'save-account': return submitAccount();

    default:
      return;
  }
}

/* -------------------------------- запуск игры -------------------------- */

async function playGame(placeId) {
  if (!placeId) return;
  if (!clients.roblox?.installed) {
    toast('Сначала установи Roblox — Настройки → Установка', 'err');
    view = 'settings';
    render();
    return;
  }
  try {
    const result = await api.launchGame(placeId);
    const via = result?.via === 'protocol' ? 'системный обработчик roblox://' : result?.via || 'клиент';
    toast(`Запускаю игру через ${via}`, 'ok');
  } catch (err) {
    toast(`Не удалось запустить: ${err.message}`, 'err');
  }
}

async function openRobloxApp() {
  try {
    await api.openRobloxApp();
    toast('Открываю Roblox — аккаунт меняется внутри клиента');
  } catch (err) {
    toast(err.message, 'err');
  }
}

async function refreshAll() {
  if (!state.games.length) return;
  let updated = 0;
  for (const game of [...state.games]) {
    try {
      const fresh = await api.refreshGame(game.placeId);
      upsertLocal(fresh);
      updated += 1;
      if (view === 'home') render();
    } catch {
      /* пропускаем недоступные */
    }
  }
  toast(updated ? `Обновил ${updated} из ${state.games.length}` : 'Не удалось обновить — проверь интернет', updated ? 'ok' : 'err');
}

async function loadRecommendations(sortId) {
  const recs = ui.recs;
  recs.loading = true;
  recs.error = null;
  if (sortId) recs.active = sortId;
  if (view === 'home' || view === 'search') render();

  try {
    if (!recs.sorts.length) {
      try {
        recs.sorts = await api.getSorts();
      } catch {
        recs.sorts = [];
      }
    }
    const data = await api.getRecommendations(recs.active);
    recs.games = data.games || [];
  } catch (err) {
    recs.error = err.message;
  }

  recs.loading = false;
  if (view === 'home' || view === 'search') render();
}

async function runSearch(pageToken) {
  const input = $('#search-input');
  const query = (input?.value ?? ui.search.query).trim();
  if (!query) {
    input?.focus();
    return;
  }

  ui.search.query = query;
  ui.search.ran = true;
  ui.search.loading = true;
  ui.search.error = null;
  if (!pageToken) {
    ui.search.games = [];
    ui.search.next = null;
  }
  if (view === 'search') render();

  try {
    const result = await api.searchGames(query, pageToken || undefined);
    ui.search.games = pageToken ? ui.search.games.concat(result.games) : result.games;
    ui.search.next = result.nextPageToken || null;
  } catch (err) {
    ui.search.error = err.message;
  }

  ui.search.loading = false;
  if (view === 'search') render();
}

async function refreshFriends() {
  try {
    const friends = await api.refreshFriends();
    if (Array.isArray(friends)) {
      state.friends = friends;
      if (view === 'friends') render();
    }
  } catch {
    /* без сети останутся инициалы */
  }
}

async function addFriendFromForm(form) {
  const input = form.querySelector('#friend-input');
  const button = form.querySelector('button[type="submit"]');
  const value = input?.value?.trim();
  if (!value) {
    input?.focus();
    return;
  }

  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = 'Ищу…';
  try {
    const result = await api.addFriend(value);
    state.friends = result.friends;
    render();
    toast(`Добавил ${result.friend.displayName || result.friend.name}`, 'ok');
  } catch (err) {
    button.disabled = false;
    button.textContent = oldText;
    toast(err.message, 'err');
  }
}

async function hydrateGames() {
  const missing = state.games.filter((g) => !g.iconUrl || !g.name);
  for (const game of missing.slice(0, 12)) {
    try {
      const fresh = await api.refreshGame(game.placeId);
      upsertLocal(fresh);
      if (view === 'home') render();
    } catch {
      /* тихо: останется заглушка */
    }
    await new Promise((r) => setTimeout(r, 220));
  }
}

function upsertLocal(game) {
  const index = state.games.findIndex((g) => g.placeId === game.placeId);
  if (index >= 0) state.games[index] = { ...state.games[index], ...game };
  else state.games.unshift(game);
}

/* ------------------------------- установка ----------------------------- */

async function installRoblox() {
  if (ui.installing) return;
  ui.installing = true;
  ui.installP = { phase: 'resolve', message: 'Готовлюсь к загрузке…' };
  render();
  try {
    const result = await api.installRoblox();
    clients = result.clients;
    ui.installing = false;
    ui.installP = { phase: 'done', message: 'Roblox установлен', percent: 100 };
    render();
    toast('Roblox установлен', 'ok');
  } catch (err) {
    ui.installing = false;
    ui.installP = { phase: 'error', message: err.message };
    render();
    toast(`Установка не удалась: ${err.message}`, 'err');
  }
}

/* -------------------------------- модалки ------------------------------ */

function openModal(html) {
  const root = $('#modal-root');
  root.hidden = false;
  root.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
}

function closeModal() {
  const root = $('#modal-root');
  root.hidden = true;
  root.innerHTML = '';
  ui.pendingGame = null;
  ui.pendingConfirm = null;
  ui.editingAccountId = null;
}

function openConfirm(title, text, onYes) {
  ui.pendingConfirm = onYes;
  openModal(`
    <h3>${esc(title)}</h3>
    <div class="modal-sub">${esc(text)}</div>
    <div class="modal-actions">
      <button class="btn btn-soft" data-action="close-modal">Отмена</button>
      <button class="btn btn-danger" data-action="confirm-yes">Подтвердить</button>
    </div>`);
}

function openAddGameModal() {
  ui.pendingGame = null;
  openModal(`
    <h3>Добавить игру</h3>
    <div class="modal-sub">Вставь ссылку с roblox.com или ID игры — подтяну название и обложку.</div>
    <div class="field">
      <label for="game-input">Ссылка или ID</label>
      <input id="game-input" class="input" placeholder="https://www.roblox.com/games/2753915549/Blox-Fruits" autocomplete="off" />
    </div>
    <div id="game-preview"></div>
    <div class="modal-actions">
      <button class="btn btn-soft" data-action="close-modal">Отмена</button>
      <button class="btn btn-primary" id="game-submit" data-action="submit-game">Найти</button>
    </div>`);

  const input = $('#game-input');
  input.focus();
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      submitGame().catch((err) => toast(err.message, 'err'));
    }
  });
}

function renderGamePreview(game) {
  const art = game.bannerUrl || game.iconUrl || '';
  $('#game-preview').innerHTML = `
    <div class="preview">
      <div class="pv-art ${art ? '' : 'no-art'}" ${artStyle(art, hueFor(game))}></div>
      <div style="min-width:0">
        <div class="pv-name">${esc(game.name)}</div>
        <div class="pv-sub">${esc([game.creator, game.playing != null ? `${fmt(game.playing)} играют` : ''].filter(Boolean).join(' · ') || 'Roblox')}</div>
      </div>
    </div>`;
}

async function submitGame() {
  const button = $('#game-submit');
  if (!button) return;

  if (ui.pendingGame) {
    const game = ui.pendingGame;
    try {
      button.disabled = true;
      const result = await api.addGame(game.placeId);
      upsertLocal(result.game);
      closeModal();
      render();
      toast(result.existed ? `Обновил: ${result.game.name}` : `Добавил: ${result.game.name}`, 'ok');
    } catch (err) {
      button.disabled = false;
      toast(err.message, 'err');
    }
    return;
  }

  const input = $('#game-input');
  const value = input?.value?.trim();
  if (!value) {
    input?.focus();
    return;
  }

  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = 'Ищу…';
  try {
    const game = await api.lookupGame(value);
    ui.pendingGame = game;
    renderGamePreview(game);
    button.textContent = 'Добавить в избранное';
    button.disabled = false;
  } catch (err) {
    button.textContent = oldText;
    button.disabled = false;
    toast(err.message, 'err');
  }
}

function openAccountModal(id) {
  const existing = id ? state.accounts.find((a) => a.id === id) : null;
  ui.editingAccountId = existing?.id || null;
  const account = existing || { id: '', name: '', note: '', color: ACCOUNT_COLORS[state.accounts.length % ACCOUNT_COLORS.length] };

  openModal(`
    <h3>${existing ? 'Изменить профиль' : 'Новый профиль'}</h3>
    <div class="modal-sub">Просто ярлык с именем. Логин и пароль сюда вводить не нужно и нельзя.</div>
    <div class="field">
      <label for="acc-name">Название</label>
      <input id="acc-name" class="input" maxlength="40" placeholder="Основной" value="${esc(account.name)}" autocomplete="off" />
    </div>
    <div class="field">
      <label for="acc-note">Заметка</label>
      <input id="acc-note" class="input" maxlength="60" placeholder="Например: для торговли" value="${esc(account.note || '')}" autocomplete="off" />
    </div>
    <div class="field">
      <label>Цвет</label>
      <div class="accents" id="acc-colors">
        ${ACCOUNT_COLORS.map((color) => `
          <button class="accent-dot ${account.color === color ? 'is-active' : ''}" style="--sw:${color}"
                  data-color="${color}" aria-label="Цвет ${color}"></button>`).join('')}
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-soft" data-action="close-modal">Отмена</button>
      <button class="btn btn-primary" id="acc-save" data-action="save-account">${existing ? 'Сохранить' : 'Создать'}</button>
    </div>`);

  $('#acc-name').focus();
  $('#acc-colors').addEventListener('click', (event) => {
    const dot = event.target.closest('[data-color]');
    if (!dot) return;
    event.stopPropagation();
    $('#acc-colors').querySelectorAll('.accent-dot').forEach((node) => node.classList.remove('is-active'));
    dot.classList.add('is-active');
  });
}

async function submitAccount() {
  const name = $('#acc-name')?.value?.trim();
  const note = $('#acc-note')?.value?.trim() || '';
  const color = $('#acc-colors .accent-dot.is-active')?.dataset.color || ACCOUNT_COLORS[0];
  if (!name) {
    $('#acc-name')?.focus();
    toast('Дай профилю название', 'err');
    return;
  }

  const editingId = ui.editingAccountId;
  const accounts = state.accounts.map((a) => ({ ...a }));
  const target = editingId ? accounts.find((a) => a.id === editingId) : null;

  if (target) {
    target.name = name;
    target.note = note;
    target.color = color;
  } else {
    accounts.push({
      id: `acc-${Date.now().toString(36)}`,
      name,
      note,
      color
    });
  }

  const patch = { accounts };
  if (!state.activeAccountId && accounts.length) patch.activeAccountId = accounts[0].id;
  await save(patch);
  closeModal();
  render();
  toast(target ? 'Профиль обновлён' : 'Профиль создан', 'ok');
}

/* -------------------------------- демо-режим --------------------------- */

async function demoLookup(input) {
  await new Promise((r) => setTimeout(r, 450));
  const match = String(input).match(/(\d{4,20})/);
  if (!match) throw new Error('Не понял ссылку. Нужен ID игры или ссылка roblox.com/games/…');
  return {
    placeId: Number(match[1]),
    name: `Игра ${match[1]}`,
    creator: 'Roblox',
    playing: 12345,
    visits: 987654,
    iconUrl: null,
    bannerUrl: null
  };
}

function createDemoApi() {
  let demo = {
    version: 1,
    theme: 'midnight',
    accent: 'violet',
    background: 'aurora',
    reduceMotion: false,
    launchMode: 'auto',
    customClientPath: '',
    games: [
      { placeId: 2753915549, name: 'Blox Fruits', creator: 'Gamer Robot', playing: 214000, visits: 42000000000, iconUrl: null, bannerUrl: null },
      { placeId: 920587237, name: 'Adopt Me!', creator: 'Uplift Games', playing: 96000, visits: 38000000000, iconUrl: null, bannerUrl: null },
      { placeId: 1962086868, name: 'Tower of Hell', creator: 'YXCeptional Studios', playing: 41000, visits: 25000000000, iconUrl: null, bannerUrl: null },
      { placeId: 606849621, name: 'Jailbreak', creator: 'Badimo', playing: 28000, visits: 21000000000, iconUrl: null, bannerUrl: null }
    ],
    featuredPlaceId: 2753915549,
    accounts: [
      { id: 'acc-main', name: 'Основной', note: 'Главный аккаунт', color: '#8b5cf6' },
      { id: 'acc-alt', name: 'Второй', note: 'для тестов', color: '#22d3ee' }
    ],
    activeAccountId: 'acc-main',
    friends: [
      { id: 1, name: 'builderman', displayName: 'builderman', avatarUrl: null },
      { id: 156, name: 'Roblox', displayName: 'Roblox', avatarUrl: null }
    ]
  };

  const demoClients = () => ({
    roblox: { installed: true, version: '4ea8e85481e34f46', path: 'C:\\Users\\Garaaimi\\AppData\\Local\\Roblox\\Versions\\version-4ea8e85481e34f46\\RobloxPlayerBeta.exe' },
    fishstrap: { installed: true, path: 'C:\\Users\\Garaaimi\\AppData\\Local\\Fishstrap\\Fishstrap.exe' },
    bloxstrap: { installed: false, path: null },
    protocol: { kind: 'roblox', exe: 'C:\\Users\\Garaaimi\\AppData\\Local\\Roblox\\Versions\\version-4ea8e85481e34f46\\RobloxPlayerBeta.exe', raw: '' }
  });

  return {
    getState: async () => ({ state: structuredClone(demo), clients: demoClients() }),
    saveState: async (patch) => {
      demo = { ...demo, ...patch };
      return structuredClone(demo);
    },
    resetState: async () => structuredClone(demo),
    lookupGame: async (input) => demoLookup(input),
    addGame: async (input) => {
      const game = await demoLookup(input);
      const existed = demo.games.some((g) => g.placeId === game.placeId);
      if (!existed) demo.games.unshift(game);
      return { game, existed };
    },
    refreshGame: async (placeId) => demo.games.find((g) => g.placeId === Number(placeId)) || { placeId: Number(placeId), name: `Игра ${placeId}` },
    removeGame: async (placeId) => {
      demo.games = demo.games.filter((g) => g.placeId !== Number(placeId));
      if (demo.featuredPlaceId === Number(placeId)) demo.featuredPlaceId = demo.games[0]?.placeId ?? null;
      return structuredClone(demo);
    },
    featureGame: async (placeId) => {
      demo.featuredPlaceId = Number(placeId);
      return demo.featuredPlaceId;
    },
    launchGame: async () => ({ ok: true, via: 'protocol (демо)' }),
    openGamePage: async () => true,
    detectClients: async () => demoClients(),

    searchGames: async (query, pageToken) => {
      const q = String(query || '').toLowerCase();
      const games = demo.games.filter((game) => game.name.toLowerCase().includes(q));
      const extra = { name: `${query} Tycoon`, creator: 'Демо-студия', playing: 1200, iconUrl: null };
      return { games: pageToken ? [] : games.concat(extra), nextPageToken: null };
    },

    getSorts: async () => ([
      { id: 'top-trending', name: 'Top Trending' },
      { id: 'up-and-coming', name: 'Up-and-Coming' },
      { id: 'top-playing-now', name: 'Top Playing Now' },
      { id: 'fun-with-friends', name: 'Fun with Friends' }
    ]),

    getRecommendations: async (sortId) => ({
      sortId: sortId || 'top-trending',
      sortName: 'Top Trending',
      games: demo.games.map((game, index) => ({
        ...game,
        placeId: game.placeId + (sortId === 'top-playing-now' ? 0 : index),
        source: 'recommendation'
      }))
    }),

    addFriend: async (username) => {
      const name = String(username || '').trim();
      if (!name) throw new Error('Введи ник');
      const friend = { id: Date.now(), name, displayName: name, avatarUrl: null };
      demo.friends = [friend, ...demo.friends];
      return { friends: structuredClone(demo.friends), friend };
    },

    removeFriend: async (id) => {
      demo.friends = demo.friends.filter((friend) => String(friend.id) !== String(id));
      return structuredClone(demo.friends);
    },

    refreshFriends: async () => structuredClone(demo.friends),

    pickClient: async () => null,
    installRoblox: async () => {
      await new Promise((r) => setTimeout(r, 700));
      return { clients: demoClients(), detected: true };
    },
    openExternal: async () => true,
    openRobloxApp: async () => ({ ok: true }),
    openStateFolder: async () => 'C:\\Users\\Garaaimi\\AppData\\Roaming\\GaraBlox',
    openLog: async () => 'C:\\Users\\Garaaimi\\AppData\\Roaming\\GaraBlox\\garablox.log',
    minimize: async () => true,
    toggleMaximize: async () => true,
    close: async () => true,
    onInstallProgress: null,
    onMaximized: null
  };
}

/* ------------------------------- старт --------------------------------- */

boot().catch((err) => {
  console.error(err);
  document.body.innerHTML = `<div style="padding:40px;font-family:Segoe UI,sans-serif;color:#eee">
    <h2>GaraBlox не смог загрузиться</h2><pre style="white-space:pre-wrap;color:#f88">${esc(err.stack || err.message)}</pre></div>`;
});
