Add-Type -AssemblyName System.Drawing

$outDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'assets'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$size = 256
$bmp = New-Object System.Drawing.Bitmap($size, $size)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.Clear([System.Drawing.Color]::Transparent)

$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$r = 60
$d = $r * 2
$path.AddArc(8, 8, $d, $d, 180, 90)
$path.AddArc($size - 8 - $d, 8, $d, $d, 270, 90)
$path.AddArc($size - 8 - $d, $size - 8 - $d, $d, $d, 0, 90)
$path.AddArc(8, $size - 8 - $d, $d, $d, 90, 90)
$path.CloseFigure()

$start = New-Object System.Drawing.Point(8, 8)
$end = New-Object System.Drawing.Point(248, 248)
$c1 = [System.Drawing.Color]::FromArgb(255, 139, 92, 246)
$c2 = [System.Drawing.Color]::FromArgb(255, 34, 211, 238)
$brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($start, $end, $c1, $c2)
$g.FillPath($brush, $path)

$font = New-Object System.Drawing.Font('Segoe UI', 148, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$fmt = New-Object System.Drawing.StringFormat
$fmt.Alignment = [System.Drawing.StringAlignment]::Center
$fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
$rect = New-Object System.Drawing.RectangleF(6, 14, 244, 236)
$shadowRect = New-Object System.Drawing.RectangleF(8, 18, 244, 236)
$shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60, 10, 10, 17))
$g.DrawString('G', $font, $shadowBrush, $shadowRect, $fmt)
$g.DrawString('G', $font, [System.Drawing.Brushes]::White, $rect, $fmt)

$iconPath = Join-Path $outDir 'icon.png'
$bmp.Save($iconPath, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose()
$bmp.Dispose()

Write-Output "saved $iconPath"
